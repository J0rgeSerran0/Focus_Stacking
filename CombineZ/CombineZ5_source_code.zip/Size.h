// Size.h: interface for the CSize class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SIZE_H__E5AB25BE_7C81_43C0_AC3A_D67B35336944__INCLUDED_)
#define AFX_SIZE_H__E5AB25BE_7C81_43C0_AC3A_D67B35336944__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CSize  
{
public:
	CSize();
	virtual ~CSize();

};

#endif // !defined(AFX_SIZE_H__E5AB25BE_7C81_43C0_AC3A_D67B35336944__INCLUDED_)
