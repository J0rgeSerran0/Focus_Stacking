#if !defined(AFX_SIZE1_H__388863B6_FFCC_4E46_90C0_A8679FA83308__INCLUDED_)
#define AFX_SIZE1_H__388863B6_FFCC_4E46_90C0_A8679FA83308__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Size1.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// Size dialog

class Size : public CDialog
{
// Construction
public:

// Dialog Data
	//{{AFX_DATA(Size)
	enum { IDD = IDD_DIALOG2 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(Size)
	protected:
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(Size)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SIZE1_H__388863B6_FFCC_4E46_90C0_A8679FA83308__INCLUDED_)
